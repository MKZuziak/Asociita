class ModelException(Exception):
    """The error has occured during local training phase."""